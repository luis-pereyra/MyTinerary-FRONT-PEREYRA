function Cities() {
  return (
    <div>Cities</div>
  )
}

export default Cities