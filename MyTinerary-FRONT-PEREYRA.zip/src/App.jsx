import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Home from './pages/Home/Home';
import Cities from './pages/Cities/Cities'

function App() {
  return (
    <>
      <Home />
    </>
  )
}

export default App
