
function Footer() {
  return (
    <footer className='container app-footer'>
        <p className='text-center'>Mindhub AP MERN 08 - Luis Pereyra</p>
    </footer>
    )
}

export default Footer